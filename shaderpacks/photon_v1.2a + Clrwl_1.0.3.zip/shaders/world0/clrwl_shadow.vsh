#version 400 compatibility
#extension GL_ARB_shader_image_load_store : enable
#define WORLD_OVERWORLD
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define PROGRAM_SHADOW_BLOCK
#define PROGRAM_SHADOW_ENTITIES
#define vsh
#include "/program/clrwl_shadow.vsh"
